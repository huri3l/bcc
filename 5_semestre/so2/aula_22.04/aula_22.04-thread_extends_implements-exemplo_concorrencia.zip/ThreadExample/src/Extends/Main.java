/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Extends;

/**
 *
 * @author 20201pf.cc0165
 */
public class Main {
    public static void main(String[] args) {
        ExtendsThread thread1 = new ExtendsThread("Primeiro Thread");
        thread1.start();
        
        ExtendsThread thread2 = new ExtendsThread("Segundo Thread");
        thread2.start();
    }
}
