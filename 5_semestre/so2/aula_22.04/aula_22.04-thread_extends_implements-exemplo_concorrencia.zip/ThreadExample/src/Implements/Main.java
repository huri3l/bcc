/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import Implements.ImplementsRunnable;

/**
 *
 * @author 20201pf.cc0165
 */
public class Main {
    public static void main(String[] args) {
        ImplementsRunnable thread1 = new ImplementsRunnable("Primeiro Thread");
        ImplementsRunnable thread2 = new ImplementsRunnable("Segundo Thread");
        
        Thread i_thread1 = new Thread(thread1);
        i_thread1.start();
        
        Thread i_thread2 = new Thread(thread2);
        i_thread2.start();
    }
}
