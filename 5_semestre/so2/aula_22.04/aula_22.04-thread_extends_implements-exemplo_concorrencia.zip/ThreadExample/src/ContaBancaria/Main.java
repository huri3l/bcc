/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ContaBancaria;

/**
 *
 * @author 20201pf.cc0165
 */
public class Main {
    public static void main(String[] args) {
        final ContaBancaria conta = new ContaBancaria(100000);
        
        Cliente pai = new Cliente("Pai", conta);
        Cliente mae = new Cliente("Mãe", conta);
        Cliente filho = new Cliente("Filho", conta);
        
        pai.start();
        mae.start();
        filho.start();
    }
}
