/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ContaBancaria;

/**
 *
 * @author 20201pf.cc0165
 */
public class Cliente extends Thread {
    private static AgenciaBancaria agencia = new AgenciaBancaria();
    private ContaBancaria conta = null;
    private double saldo = 100;
    
    public Cliente(String nome, ContaBancaria conta) {
        super(nome);
        this.conta = conta;
    }
    
    @Override
    public void run() {
        try {
            double total = 0;
            while(this.agencia.saque(conta, saldo)) {
                total += saldo;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static AgenciaBancaria getAgencia() {
        return agencia;
    }

    public static void setAgencia(AgenciaBancaria agencia) {
        Cliente.agencia = agencia;
    }

    public ContaBancaria getConta() {
        return conta;
    }

    public void setConta(ContaBancaria conta) {
        this.conta = conta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    
}
