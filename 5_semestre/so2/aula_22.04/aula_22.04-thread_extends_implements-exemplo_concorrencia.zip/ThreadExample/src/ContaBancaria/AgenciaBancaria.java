/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ContaBancaria;

/**
 *
 * @author 20201pf.cc0165
 */
public class AgenciaBancaria {
    public boolean saque(ContaBancaria contaBancaria, double valor) {
        double saldo = contaBancaria.getSaldo();
        
        if(saldo < valor) {
            System.out.println("Saldo insuficiente");
            return false;
        }
        
        double novoSaldo = saldo - valor;
        System.out.println(Thread.currentThread().getName() + " sacou R$" + valor + ". Saldo após o saque R$ " + novoSaldo);
        contaBancaria.setSaldo(novoSaldo);
        return true;
    }
}
