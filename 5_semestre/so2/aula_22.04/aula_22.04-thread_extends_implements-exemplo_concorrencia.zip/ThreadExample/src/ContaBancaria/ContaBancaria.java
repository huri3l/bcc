/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ContaBancaria;

/**
 *
 * @author 20201pf.cc0165
 */
public class ContaBancaria {
    private double saldo = 0;
    
    public ContaBancaria(double saldo) {
        this.saldo = saldo;
        
        System.out.println("Conta bancária criada");
        System.out.println("Seu saldo é de: R$ " + this.getSaldo());
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
