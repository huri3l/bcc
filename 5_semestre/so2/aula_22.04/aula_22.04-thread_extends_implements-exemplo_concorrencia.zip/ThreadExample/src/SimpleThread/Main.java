/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SimpleThread;

/**
 *
 * @author 20201pf.cc0165
 */
public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Primeiro Thread...");
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
