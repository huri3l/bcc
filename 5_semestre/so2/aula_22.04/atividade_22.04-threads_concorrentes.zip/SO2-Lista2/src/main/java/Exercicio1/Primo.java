/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio1;

/**
 *
 * @author 20201pf.cc0165
 */
public class Primo extends Thread {
    private int comecoVerificacao;
    private int finalVerificacao;
    
    public Primo(String nome, int comecoVerificacao, int finalVerificacao) {
        super(nome);
        this.comecoVerificacao = comecoVerificacao;
        this.finalVerificacao = finalVerificacao;
    }
    
    private static boolean verificaPrimo(int num) {
        for (int i = 2; i < num; i++) {
            if (num % i == 0) 
                return false;
        }
        return true;
    }
    
    @Override
    public void run() {
        try {
            for(int i = getComecoVerificacao(); i <= getFinalVerificacao(); i++) {
                if (verificaPrimo(i))
                    System.out.println(Thread.currentThread().getName() + " verificou que o número " + i + " é primo.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getComecoVerificacao() {
        return comecoVerificacao;
    }

    public void setComecoVerificacao(int comecoVerificacao) {
        this.comecoVerificacao = comecoVerificacao;
    }

    public int getFinalVerificacao() {
        return finalVerificacao;
    }

    public void setFinalVerificacao(int finalVerificacao) {
        this.finalVerificacao = finalVerificacao;
    }
    
    
}
