/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio2;

/**
 *
 * @author hurie
 */
public class Calculadora {
    public void soma(int num1, int num2) {
        int total = 0;
        
        total = num1 + num2;
        
        System.out.println("Resultado da Soma do Usuario '" + Thread.currentThread().getName() + "' e de: " + total);
    }
    
    public void subtracao(int num1, int num2) {
        int total = 0;
        
        total = num1 - num2;
        
        System.out.println("Resultado da Subtracao do Usuario '" + Thread.currentThread().getName() + "' e de: " + total);
    }
    
    public void multiplicacao(int num1, int num2) {
        int total = 0;
        
        total = num1 * num2;
        
        System.out.println("Resultado da Multiplicacao do Usuario '" + Thread.currentThread().getName() + "' e de: " + total);
    }
    
    public void divisao(int num1, int num2) {
        float total = 0;
        
        total = num1 / num2;
        
        System.out.println("Resultado da Divisao do Usuario '" + Thread.currentThread().getName() + "' e de: " + total);
    }
}
