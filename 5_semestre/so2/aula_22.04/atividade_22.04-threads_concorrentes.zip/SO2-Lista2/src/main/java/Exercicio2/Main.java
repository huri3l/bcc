/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio2;

/**
 *
 * @author hurie
 */
public class Main {
    public static void main(String[] args) {
        Usuario usuario1 = new Usuario("Huriel", "soma", 4, 5);
        Usuario usuario2 = new Usuario("Jovita", "subtracao", 10, 8);
        Usuario usuario3 = new Usuario("Bernardo", "multiplicacao", 7, 5);
        Usuario usuario4 = new Usuario("Victor", "divisao", 20, 10);
        Usuario usuario5 = new Usuario("Ederson", "soma", 3, 9);
        Usuario usuario6 = new Usuario("Emanuel", "subtracao", 23, 18);
        Usuario usuario7 = new Usuario("Joao", "multiplicacao", 4, 5);
        Usuario usuario8 = new Usuario("Juliano", "divisao", 5, 4);
        
        usuario1.start();
        usuario2.start();
        usuario3.start();
        usuario4.start();
        usuario5.start();
        usuario6.start();
        usuario7.start();
        usuario8.start();
    }
}
