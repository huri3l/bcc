/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio3;

import java.util.Calendar;

/**
 *
 * @author hurie
 */
public class HoraAtual extends Thread {
    public HoraAtual(String nome) {
        super(nome);
    }
    
    @Override
    public void run() {
        try {
            Calendar moment = Calendar.getInstance();
            
            for(int i = 0; i < 10; i++) {
                System.out.println(Thread.currentThread().getName() + ": " + moment.get(Calendar.HOUR_OF_DAY) + ":" + moment.get(Calendar.MINUTE));
                Thread.currentThread().sleep(10000);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
