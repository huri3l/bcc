/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio3;

import java.io.IOException;

/**
 *
 * @author hurie
 */
public class Main {
    public static void main(String[] args) throws IOException {
        Tweet thread_tweet = new Tweet("Thread 1");
        HoraAtual thread_hora_atual = new HoraAtual("Thread 2");
        Usuario thread_usuario = new Usuario("Thread 3");        
        
        thread_tweet.start();
        thread_hora_atual.start();
        thread_usuario.start();
    }
}
