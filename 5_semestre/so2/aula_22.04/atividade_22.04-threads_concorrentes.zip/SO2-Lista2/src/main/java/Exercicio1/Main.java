/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio1;

/**
 *
 * @author 20201pf.cc0165
 */
public class Main {
    public static void main(String[] args) {
        for(int i = 2; i < 100000; i += 1000) {
            Primo primo = new Primo("Thread " + ((i - 2)/ 1000), i, i + 1000);
            primo.start();
        }
    }
}
