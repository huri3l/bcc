/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 *
 * @author hurie
 */
public class Tweet extends Thread {
    
    public Tweet(String nome) {
        super(nome);
    }
    
    public static String tweetLido(int linha) throws IOException {
        return Files.readAllLines(Paths.get(System.getProperty("user.dir") + "/src/main/java/Exercicio3/" + "tweets.txt")).get(linha);
    }
    
    @Override
    public void run() {
        try {
            for(int i = 0; i < 13; i++) {
                System.out.println(Thread.currentThread().getName() + ": " + tweetLido(i));
                Thread.currentThread().sleep(8000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
