/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio2;

/**
 *
 * @author hurie
 */
public class Usuario extends Thread {
    private static Calculadora calculadora = new Calculadora();
    private String operacao;
    private int valor1;
    private int valor2;
    
    public Usuario(String nome, String operacao, int valor1, int valor2) {
        super(nome);
        this.operacao = operacao;
        this.valor1 = valor1;
        this.valor2 = valor2;
    }
    
    @Override
    public void run() {
        try {
            if (null == operacao) {
                System.out.println("Operação desconhecida!");
            } else switch (operacao) {
                case "soma":
                    this.calculadora.soma(getValor1(), getValor2());
                    break;
                case "subtracao":
                    this.calculadora.subtracao(getValor1(), getValor2());
                    break;
                case "multiplicacao":
                    this.calculadora.multiplicacao(getValor1(), getValor2());
                    break;
                case "divisao":
                    this.calculadora.divisao(getValor1(), getValor2());
                    break;
                default:
                    System.out.println("Operação desconhecida!");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Calculadora getCalculadora() {
        return calculadora;
    }

    public static void setCalculadora(Calculadora calculadora) {
        Usuario.calculadora = calculadora;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }

    public int getValor1() {
        return valor1;
    }

    public void setValor1(int valor1) {
        this.valor1 = valor1;
    }

    public int getValor2() {
        return valor2;
    }

    public void setValor2(int valor2) {
        this.valor2 = valor2;
    }
    
    
}
